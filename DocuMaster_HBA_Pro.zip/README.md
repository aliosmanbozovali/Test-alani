# DocuMaster HBA Pro - Belge Yönetim Sistemi

## Kurulum

1. Python 3.11+ yükleyin
2. Gerekli paketleri yükleyin:
   ```
   pip install flask flask-cors pillow pypdf2 pytesseract python-docx werkzeug
   ```
3. Sistemi başlatın:
   ```
   python web_api.py
   ```
4. Tarayıcıda açın: http://localhost:5000

## Giriş Bilgileri
- Kullanıcı: admin
- Şifre: admin123

## Özellikler
- Belge yükleme ve yönetimi
- Kategori bazlı organizasyon
- Arama ve filtreleme
- Paylaşım linkleri
- Önizleme desteği
- Audit log sistemi
